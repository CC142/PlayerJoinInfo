package org.ccbeautify.cc142;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;


public final class PlayerJoinInfo extends JavaPlugin implements Listener, CommandExecutor {

private FileConfiguration config = this.getConfig();
    private String playerjoinprefix = config.getString("playerjoinprefix");
    private String playerjoinsuffix = config.getString("playerjoinsuffix");
    private String playerexitprefix = config.getString("playerexitprefix");
    private String playerexitsuffix = config.getString("playerexitsuffix");


    @Override
    public void onEnable() {
        this.getCommand("playerjoininfo").setExecutor(this);
        // Plugin startup logic
        Bukkit.getConsoleSender().sendMessage("§a美化组件-玩家加入美化加载成功!");
        getServer().getPluginManager().registerEvents(this, this);
        this.saveDefaultConfig();

    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender,@NotNull Command command,@NotNull String label,@NotNull String[] args){
        this.reloadConfig();
        config = this.getConfig();
        return true;
    }
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent e){
        String message =  playerjoinprefix + e.getPlayer().getName() + playerjoinsuffix;
        e.setJoinMessage(message);
    }
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent e) {
        String message = playerexitprefix + e.getPlayer().getName() + playerexitsuffix;
        e.setQuitMessage(message);
    }
    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
}
